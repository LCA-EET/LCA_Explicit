## Love Conquers All (LCA) Release Notes

# Report any bugs to LCAMod@danielvalle.net, or the Gibberlings 3 Forum Post 
* Link to forum post: https://www.gibberlings3.net/forums/topic/36832-announcing-love-conquers-all-lca-%E2%80%93-corwin-romance-mod-for-eet

# v1.1, 2024-01-13
* Dialog improvements based on feedback received.

# v1.0c, 2023-12-15
* Fixed a bug that could cause Corwin to use the incorrect portrait during the intimate encounter in Baldur's Gate.

# v1.0b, 2023-11-22
* Refactored integration with the LCA mod. No new content.

# v1.0a, 2023-11-20
* Fixed a bug in the hook for the Spellhold encounter.

# v1.0, 2023-09-30
* Initial release - enjoy!

# RC1, 2023-09-25
* Fixed the hook to the Spellhold encounter between Corwin and Irenicus.
* Final improvements before the initial release, scheduled for this month.
