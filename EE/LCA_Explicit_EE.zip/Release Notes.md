## Love Conquers All (LCA) Explicit Release Notes

# If you require assistance with the mod, or find any bugs, you can contact me as indicated below. I'd also welcome any feedback or constructive criticism you have to offer.
* Email: LCAMod@danielvalle.net
* Discord Server: https://discord.gg/hwGf39gW9g
* Gibberlings 3 Forum Post: https://www.gibberlings3.net/forums/topic/36832-announcing-love-conquers-all-lca-%E2%80%93-corwin-romance-mod-for-eet
* Beamdog Forum Post: https://forums.beamdog.com/discussion/87688/announcing-love-conquers-all-lca-corwin-romance-mod-for-eet

# v1.2, 2024-09-25
* Added compatibility with the EE version of the LCA mod.

# v1.2, 2024-08-28
* Dialog and sound improvements.

# v1.1, 2024-01-13
* Dialog improvements based on feedback received.

# v1.0c, 2023-12-15
* Fixed a bug that could cause Corwin to use the incorrect portrait during the intimate encounter in Baldur's Gate.

# v1.0b, 2023-11-22
* Refactored integration with the LCA mod. No new content.

# v1.0a, 2023-11-20
* Fixed a bug in the hook for the Spellhold encounter.

# v1.0, 2023-09-30
* Initial release - enjoy!

# RC1, 2023-09-25
* Fixed the hook to the Spellhold encounter between Corwin and Irenicus.
* Final improvements before the initial release, scheduled for this month.
